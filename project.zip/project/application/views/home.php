		<!-- Header -->
		<header>
			<div class="container">
				<div class="slider-container">
					<div class="intro-text">
						<div class="intro-lead-in">Bem vindo ao gerenciador de projetos</div>
						<div class="intro-heading">Vamos Iniciar...</div>

					</div>
				</div>
			</div>
		</header>

		<section >
			<div class="container">
				
			</div>
		<p id="back-top">
			<a href="#top"><i class="fa fa-angle-up"></i></a>
		</p>